import Counter from './Counter.js';
export default function App() {

  return (
    <>
      <Counter/>
    </>
  )
}